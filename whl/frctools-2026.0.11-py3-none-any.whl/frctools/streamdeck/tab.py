class StreamDeckTab:
    pass